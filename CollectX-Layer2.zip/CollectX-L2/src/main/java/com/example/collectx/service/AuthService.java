package com.example.collectx.service;

import com.example.collectx.DTO.LoginRequest;
import com.example.collectx.DTO.LoginResponse;
import com.example.collectx.DTO.SignupRequest;
import com.example.collectx.entity.AuditLog;
import com.example.collectx.entity.Session;
import com.example.collectx.entity.User;
import com.example.collectx.exception.ResourceNotFoundException;
import com.example.collectx.repository.AuditLogRepository;
import com.example.collectx.repository.SessionRepository;
import com.example.collectx.repository.UserRepository;
import com.example.collectx.util.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository     userRepository;
    private final AuditLogRepository auditLogRepository;
    private final SessionRepository  sessionRepository;
    private final JwtUtil            jwtUtil;
    private final PasswordEncoder    passwordEncoder;  // BCrypt injected from SecurityConfig

    // ── Signup ────────────────────────────────────────────────────────────────

    public String signup(SignupRequest request) {

        if (userRepository.findByEmail(request.getEmail()).isPresent()) {
            throw new IllegalArgumentException("Email is already registered");
        }

        User user = new User();
        user.setName(request.getName());
        user.setEmail(request.getEmail().toLowerCase());
        user.setPassword(passwordEncoder.encode(request.getPassword())); // BCrypt hash
        user.setRoles("AGENT");
        user.setStatus("ACTIVE");

        userRepository.save(user);

        auditLog("SIGNUP", "AUTH", user);
        return "User registered successfully";
    }

    // ── Login ─────────────────────────────────────────────────────────────────

    public LoginResponse login(LoginRequest request) {

        User user = userRepository.findByEmail(request.getEmail().toLowerCase())
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        if (!"ACTIVE".equalsIgnoreCase(user.getStatus())) {
            throw new IllegalArgumentException("Account is deactivated. Contact your administrator.");
        }

        // BCrypt comparison — never plain text
        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            throw new IllegalArgumentException("Invalid password");
        }

        String token = jwtUtil.generateToken(
                user.getEmail(),
                user.getRoles(),
                (long) user.getUserId()
        );

        // Persist session
        Session session = new Session();
        session.setToken(token);
        session.setLoginTime(LocalDateTime.now());
        session.setUser(user);
        sessionRepository.save(session);

        auditLog("LOGIN", "AUTH", user);
        return new LoginResponse(token);
    }

    // ── Private helper ────────────────────────────────────────────────────────

    private void auditLog(String action, String resource, User user) {
        AuditLog log = new AuditLog();
        log.setAction(action);
        log.setResource(resource);
        log.setTimestamp(LocalDateTime.now());
        log.setUser(user);
        auditLogRepository.save(log);
    }
}
